package com.university.chatbot.Controller;

import com.university.chatbot.service.RuleBasedChatbotService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rule-chat")
public class RuleBasedChatbotController {

    private final RuleBasedChatbotService chatbotService;

    public RuleBasedChatbotController(RuleBasedChatbotService chatbotService) {
        this.chatbotService = chatbotService;
    }

    @PostMapping("/message")
    public String chat(@RequestBody String userMessage) {
        return chatbotService.getResponse(userMessage);
        
    }
    @GetMapping("/")
    public String home() {
        return "chat";
    }
}
