package com.university.chatbot.service;

import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;

@Service
public class RuleBasedChatbotService {
    
    private final Map<String, String> responses = new HashMap<>();

    public RuleBasedChatbotService() {
        // Define simple rules
        responses.put("hi", "Hello! How can I assist you today?");
        responses.put("hello", "Hi there! What would you like to know?");
        responses.put("courses", "We offer courses in Computer Science, Business, and Engineering.");
        responses.put("admission", "Our admission process is open! Visit our website for more details.");
        responses.put("contact", "You can contact us at info@sburanchi.ac.in or call 18008906077.");
        responses.put("location", "We are located at Sarala Birla University in Birla Knowledge city Mahilong , Ranchi, Jharkhand.");
    }

    public String getResponse(String userInput) {
        userInput = userInput.toLowerCase().trim();
        for (String keyword : responses.keySet()) {
            if (userInput.contains(keyword)) {
                return responses.get(keyword);
            }
        }
        return responses.getOrDefault(userInput, "I'm sorry, I don't understand. Can you rephrase?");
    }
}