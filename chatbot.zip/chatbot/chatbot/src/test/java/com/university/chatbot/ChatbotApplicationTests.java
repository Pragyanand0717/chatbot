/*package com.university.chatbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatbotApplicationTests {
	@Test
	void contextLoads() 
	{
		
	}
}
*/
/*package com.university.chatbot;

import com.university.chatbot.service.RuleBasedChatbotService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class ChatbotApplicationTests {
  
    @Autowired
    private RuleBasedChatbotService chatbotService;

    @Test
    void contextLoads() {
        // Test if the application context loads successfully
    }

    @Test
    void testChatbotService() {
        String userMessage = "hi";
        String expectedResponse = "Hello! How can I assist you today?";

        String actualResponse = chatbotService.getResponse(userMessage);

        assertThat(actualResponse).isEqualTo(expectedResponse);
    }
}*/