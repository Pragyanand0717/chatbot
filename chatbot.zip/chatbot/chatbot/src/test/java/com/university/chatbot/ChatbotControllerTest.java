package com.university.chatbot;

import com.university.chatbot.Controller.RuleBasedChatbotController;
import com.university.chatbot.service.RuleBasedChatbotService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
@WebMvcTest(RuleBasedChatbotController.class)
class ChatbotControllerTests 
{
    @Autowired
    private MockMvc mockMvc;

    @Mock
    private RuleBasedChatbotService chatbotService;

    @InjectMocks
    private RuleBasedChatbotController chatbotController;

    @Test
    void testGetResponse() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(chatbotController).build();

        String userMessage = "hi";
        String chatbotResponse = "Hello! How can I assist you today?";

        when(chatbotService.getResponse(userMessage)).thenReturn(chatbotResponse);

        mockMvc.perform(post("/api/rule-chat/message")
            .contentType("application/json")
            .content(userMessage))
            .andExpect(status().isOk())
            .andExpect(content().string(chatbotResponse));
    }
}
